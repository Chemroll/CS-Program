package com.example.kingsleyotiamponsah;

public class Util {

    //referencing database related items
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Contact_db";
    public static final String TABLE_NAME = "contacts";

    //creating contacts
    public static final String key_id = "id";
    public static final int key_date = Integer.parseInt("date");
    public static final int key_weight = Integer.parseInt("weight");

}
