package com.example.kingsleyotiamponsah;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;


@RunWith(AndroidJUnit4.class)
public class MainActivity extends AppCompatActivity{
    private EditText EnterPasswordText;
    private EditText EnterUsernameText;

    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.kingsleyotiamponsah", appContext.getPackageName());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView EnterUsernameText = findViewById(R.id.EnterUsernameText);
        TextView EnterPasswordText = findViewById(R.id.EnterPasswordText);
        Button login = findViewById(R.id.login);

        EnterUsernameText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = EnterUsernameText.getText().toString();
                if (username.isEmpty()) {
                    EnterUsernameText.setText("please enter username");
                } else {
                    EnterUsernameText.setText();
                }

            }
        });

        EnterPasswordText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = EnterPasswordText.getText().toString();
                if (password.isEmpty()) {
                    EnterPasswordText.setText("please enter password");
                } else {
                    EnterPasswordText.setText();
                }

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login.setActivated();
            }
        });



    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DatabaseHandler db = new DatabaseHandler(MainActivity.this);

        //create first contact object
        Contact Kingsley = new Contact();
        Kingsley.setDate("January 1, 2025");
        Kingsley.setWeight("180");

        db.addContact(Kingsley);

    }




}